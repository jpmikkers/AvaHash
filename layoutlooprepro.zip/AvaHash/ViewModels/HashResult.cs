﻿namespace AvaHash.ViewModels;

using System;

public partial class HashResult
{
    public string HashType { get; set; } = String.Empty;
    public string Hash { get; set; } = String.Empty;
}
