﻿namespace AvaHash.ViewModels;
using CommunityToolkit.Mvvm.ComponentModel;

public class ViewModelBase : ObservableObject
{
}
